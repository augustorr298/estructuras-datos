namespace SensorSubmarino;

public partial class frmOperaciones : Form
{
    public frmOperaciones()
    {
        InitializeComponent();
    }

    private void operacionesToolStripMenuItem_Click(object sender, EventArgs e)
    {
        Form1 f1 = new Form1();
        f1.Visible = true;
        this.Visible = false;   //ocultar actuall
    }
}