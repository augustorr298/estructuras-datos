namespace SensorSubmarino;

public partial class frmAcceso : Form
{
    public frmAcceso()
    {
        InitializeComponent();
    }
    
    char []abc= {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    char []julio= {'d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','a','b','c',};

    public int i, j = 0;
    string cifrado = "";
    string usuario = "uriel";
    string contra = "krod";
    
    public string cifrar(string contras)
    {

        for (int i = 0; i < contra.Length; i++)
        {
            for (int j = 0; j <= 25; j++)
            {
                if (contras[i] == abc[j])
                {
                    cifrado += julio[j];
                    
                }
            }
        }
        
        
        return cifrado;
    }
    
    private void button1_Click(object sender, EventArgs e)
    {
        if (txtUsuario.Text.Trim() != "")
        {
            if (txtContra.Text.Trim() != "")
            {
                if (txtUsuario.Text == usuario)
                {
                    if (cifrar(txtContra.Text) == contra)
                    {
                        frmOperaciones fo = new frmOperaciones();
                        fo.Visible = true;
                        this.Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Contraseña incorrecta");
                        cifrado = "";
                        txtContra.Clear();
                        txtContra.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Usuario incorrecto");
                    txtUsuario.Clear();
                    txtUsuario.Focus();
                }
            }
            else
            {
                MessageBox.Show("Ingrese la contraseña");
                txtContra.Focus();
            }
        }
        else
        {
                MessageBox.Show("Ingrese el usuario");
                txtUsuario.Focus();

        }
        
        
        
    }
}