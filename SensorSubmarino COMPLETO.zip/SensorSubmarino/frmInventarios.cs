using System.Data;

namespace SensorSubmarino;

public partial class frmInventarios : Form
{
    public frmInventarios()
    {
        InitializeComponent();
        // Deshabilitar botones hasta que se cree el inventario
        btnInsertar.Enabled = false;
        btnConsultar.Enabled = false;
        btnModificar.Enabled = false;
        btnEliminar.Enabled = false;
        btnConfirmar.Enabled = false;
        txtValor.Enabled = false;
        txtNumProductos.Focus();
    }

    // Arreglo bidimensional para almacenar productos
    // Columna 0: Código del Producto
    // Columna 1: Cantidad en Stock
    // Columna 2: Precio Unitario
    // Columna 3: Código del Proveedor
    int n; // número de productos (filas)
    int columnas = 4; // 4 columnas de datos
    int[,] inventario; // arreglo bidimensional
    int productoActual = 0; // índice del producto actual a insertar
    string operacionActual = ""; // operación que se está realizando
    int indiceEncontrado = -1; // índice del producto encontrado
    DataTable dt = new DataTable();

    // Buscar producto por código, retorna el índice o -1 si no existe
    private int BuscarProducto(int codigo)
    {
        for (int i = 0; i < n; i++)
        {
            if (inventario[i, 0] == codigo)
            {
                return i;
            }
        }
        return -1;
    }

    // Mostrar datos en el DataGridView
    private void MostrarDatos()
    {
        dt.Clear();
        for (int i = 0; i < n; i++)
        {
            // Solo mostrar productos válidos (código != -1)
            if (inventario[i, 0] != -1)
            {
                DataRow fila = dt.NewRow();
                fila["Código"] = inventario[i, 0];
                fila["Cantidad"] = inventario[i, 1];
                fila["Precio"] = inventario[i, 2];
                fila["Proveedor"] = inventario[i, 3];
                dt.Rows.Add(fila);
            }
        }
        dtgInventario.DataSource = dt;
    }

    // Contar productos activos
    private int ContarProductosActivos()
    {
        int count = 0;
        for (int i = 0; i < n; i++)
        {
            if (inventario[i, 0] != -1)
                count++;
        }
        return count;
    }

    // Encontrar primera fila disponible (vacía o eliminada)
    private int EncontrarFilaDisponible()
    {
        for (int i = 0; i < n; i++)
        {
            if (inventario[i, 0] == -1)
                return i;
        }
        return -1; // No hay espacio
    }

    // Limpiar estado de operación
    private void LimpiarEstado()
    {
        operacionActual = "";
        indiceEncontrado = -1;
        lblValor.Text = "Valor:";
        txtValor.Clear();
        txtValor.Enabled = false;
        btnConfirmar.Enabled = false;
        btnConfirmar.Text = "Confirmar";
    }

    // ==================== EVENTOS DE BOTONES ====================

    // Botón Crear Inventario
    private void btnCrear_Click(object sender, EventArgs e)
    {
        if (txtNumProductos.Text.Trim() == "")
        {
            MessageBox.Show("Ingrese el número de productos.", "Validación", 
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtNumProductos.Focus();
            return;
        }

        n = int.Parse(txtNumProductos.Text);
        
        if (n <= 0)
        {
            MessageBox.Show("El número de productos debe ser mayor a 0.", "Validación", 
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtNumProductos.Focus();
            return;
        }

        // Crear arreglo bidimensional
        inventario = new int[n, columnas];

        // Inicializar con -1 para indicar filas vacías
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < columnas; j++)
            {
                inventario[i, j] = -1;
            }
        }

        // Configurar DataTable
        dt = new DataTable();
        dt.Columns.Add("Código", typeof(int));
        dt.Columns.Add("Cantidad", typeof(int));
        dt.Columns.Add("Precio", typeof(int));
        dt.Columns.Add("Proveedor", typeof(int));

        MessageBox.Show("Inventario creado para " + n + " productos.\n\n" +
            "Arreglo bidimensional: int[" + n + ", 4]\n" +
            "Columnas: Código, Cantidad, Precio, Proveedor", 
            "Inventario creado", MessageBoxButtons.OK, MessageBoxIcon.Information);

        // Habilitar botones
        btnInsertar.Enabled = true;
        btnConsultar.Enabled = true;
        btnModificar.Enabled = true;
        btnEliminar.Enabled = true;
        btnCrear.Enabled = false;
        txtNumProductos.Enabled = false;

        productoActual = 0;
    }

    // Botón Insertar
    private void btnInsertar_Click(object sender, EventArgs e)
    {
        // Verificar si hay espacio disponible
        int filaDisponible = EncontrarFilaDisponible();
        if (filaDisponible == -1)
        {
            MessageBox.Show("El inventario está lleno. No se pueden agregar más productos.", 
                "Inventario lleno", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        productoActual = filaDisponible;
        operacionActual = "insertar_codigo";
        lblValor.Text = "Insertando producto - Código:";
        txtValor.Enabled = true;
        txtValor.Clear();
        txtValor.Focus();
        btnConfirmar.Enabled = true;
        btnConfirmar.Text = "OK, continuar";
    }

    // Botón Consultar
    private void btnConsultar_Click(object sender, EventArgs e)
    {
        if (ContarProductosActivos() == 0)
        {
            MessageBox.Show("El inventario está vacío.", "Inventario vacío", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        operacionActual = "consultar";
        lblValor.Text = "Código a consultar:";
        txtValor.Enabled = true;
        txtValor.Clear();
        txtValor.Focus();
        btnConfirmar.Enabled = true;
        btnConfirmar.Text = "Buscar";
    }

    // Botón Modificar Stock
    private void btnModificar_Click(object sender, EventArgs e)
    {
        if (ContarProductosActivos() == 0)
        {
            MessageBox.Show("El inventario está vacío.", "Inventario vacío", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        operacionActual = "buscar_modificar";
        lblValor.Text = "Código a modificar:";
        txtValor.Enabled = true;
        txtValor.Clear();
        txtValor.Focus();
        btnConfirmar.Enabled = true;
        btnConfirmar.Text = "Buscar";
    }

    // Botón Eliminar
    private void btnEliminar_Click(object sender, EventArgs e)
    {
        if (ContarProductosActivos() == 0)
        {
            MessageBox.Show("El inventario está vacío.", "Inventario vacío", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        operacionActual = "eliminar";
        lblValor.Text = "Código a eliminar:";
        txtValor.Enabled = true;
        txtValor.Clear();
        txtValor.Focus();
        btnConfirmar.Enabled = true;
        btnConfirmar.Text = "Buscar";
    }

    // Botón Confirmar Acción
    private void btnConfirmar_Click(object sender, EventArgs e)
    {
        // Validar que el campo no esté vacío
        if (txtValor.Text.Trim() == "")
        {
            MessageBox.Show("Ingrese un valor.", "Validación", 
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtValor.Focus();
            return;
        }

        int valor = int.Parse(txtValor.Text);

        switch (operacionActual)
        {
            // ========== INSERTAR ==========
            case "insertar_codigo":
                // Verificar que el código no exista
                if (BuscarProducto(valor) != -1)
                {
                    MessageBox.Show("Ya existe un producto con ese código.", "Código duplicado", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtValor.Clear();
                    txtValor.Focus();
                    return;
                }
                inventario[productoActual, 0] = valor;
                operacionActual = "insertar_cantidad";
                lblValor.Text = "Insertando producto - Cantidad en stock:";
                txtValor.Clear();
                txtValor.Focus();
                break;

            case "insertar_cantidad":
                if (valor < 0)
                {
                    MessageBox.Show("La cantidad no puede ser negativa.", "Validación", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtValor.Clear();
                    txtValor.Focus();
                    return;
                }
                inventario[productoActual, 1] = valor;
                operacionActual = "insertar_precio";
                lblValor.Text = "Insertando producto - Precio unitario:";
                txtValor.Clear();
                txtValor.Focus();
                break;

            case "insertar_precio":
                if (valor < 0)
                {
                    MessageBox.Show("El precio no puede ser negativo.", "Validación", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtValor.Clear();
                    txtValor.Focus();
                    return;
                }
                inventario[productoActual, 2] = valor;
                operacionActual = "insertar_proveedor";
                lblValor.Text = "Insertando producto - Código proveedor:";
                txtValor.Clear();
                txtValor.Focus();
                break;

            case "insertar_proveedor":
                inventario[productoActual, 3] = valor;
                MessageBox.Show("Producto insertado correctamente.\n\n" +
                    "Código: " + inventario[productoActual, 0] + "\n" +
                    "Cantidad: " + inventario[productoActual, 1] + "\n" +
                    "Precio: " + inventario[productoActual, 2] + "\n" +
                    "Proveedor: " + inventario[productoActual, 3], 
                    "Producto insertado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MostrarDatos();
                LimpiarEstado();
                break;

            // ========== CONSULTAR ==========
            case "consultar":
                int indice = BuscarProducto(valor);
                if (indice != -1)
                {
                    MessageBox.Show("Encontrado en fila " + indice + " del arreglo\n" +
                        "───────────────────\n" +
                        "Código: " + inventario[indice, 0] + "\n" +
                        "Cantidad en stock: " + inventario[indice, 1] + "\n" +
                        "Precio unitario: $" + inventario[indice, 2] + "\n" +
                        "Código proveedor: " + inventario[indice, 3], 
                        "Consulta de producto", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Producto con código " + valor + " no encontrado.", 
                        "Producto no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                LimpiarEstado();
                break;

            // ========== MODIFICAR ==========
            case "buscar_modificar":
                indiceEncontrado = BuscarProducto(valor);
                if (indiceEncontrado != -1)
                {
                    MessageBox.Show("Encontrado en fila " + indiceEncontrado + " del arreglo\n" +
                        "───────────────────\n" +
                        "Stock actual: " + inventario[indiceEncontrado, 1] + "\n\n" +
                        "Ingrese la nueva cantidad.", 
                        "Producto encontrado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    operacionActual = "modificar_cantidad";
                    lblValor.Text = "Nueva cantidad:";
                    btnConfirmar.Text = "OK, continuar";
                    txtValor.Clear();
                    txtValor.Focus();
                }
                else
                {
                    MessageBox.Show("Producto con código " + valor + " no encontrado.", 
                        "Producto no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    LimpiarEstado();
                }
                break;

            case "modificar_cantidad":
                if (valor < 0)
                {
                    MessageBox.Show("La cantidad no puede ser negativa.", "Validación", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtValor.Clear();
                    txtValor.Focus();
                    return;
                }
                int cantidadAnterior = inventario[indiceEncontrado, 1];
                inventario[indiceEncontrado, 1] = valor;
                MessageBox.Show("Stock modificado correctamente.\n\n" +
                    "Cantidad anterior: " + cantidadAnterior + "\n" +
                    "Cantidad nueva: " + valor, 
                    "Stock modificado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MostrarDatos();
                LimpiarEstado();
                break;

            // ========== ELIMINAR ==========
            case "eliminar":
                int indiceEliminar = BuscarProducto(valor);
                if (indiceEliminar != -1)
                {
                    DialogResult confirmar = MessageBox.Show(
                        "Encontrado en fila " + indiceEliminar + " del arreglo\n" +
                        "───────────────────\n" +
                        "¿Está seguro de eliminar el producto?\n\n" +
                        "Código: " + inventario[indiceEliminar, 0] + "\n" +
                        "Cantidad: " + inventario[indiceEliminar, 1] + "\n" +
                        "Precio: $" + inventario[indiceEliminar, 2] + "\n" +
                        "Proveedor: " + inventario[indiceEliminar, 3],
                        "Confirmar eliminación", 
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (confirmar == DialogResult.Yes)
                    {
                        // Marcar toda la fila como vacía (-1)
                        inventario[indiceEliminar, 0] = -1;
                        inventario[indiceEliminar, 1] = -1;
                        inventario[indiceEliminar, 2] = -1;
                        inventario[indiceEliminar, 3] = -1;

                        MessageBox.Show("Producto eliminado correctamente.\n" +
                            "La fila " + indiceEliminar + " ahora está disponible.", 
                            "Producto eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        MostrarDatos();
                    }
                }
                else
                {
                    MessageBox.Show("Producto con código " + valor + " no encontrado.", 
                        "Producto no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                LimpiarEstado();
                break;
        }
    }

    // Botón Limpiar
    private void btnLimpiar_Click(object sender, EventArgs e)
    {
        if (inventario != null)
        {
            DialogResult confirmar = MessageBox.Show(
                "¿Desea reiniciar el inventario?\nSe perderán todos los datos.",
                "Confirmar reinicio", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmar == DialogResult.Yes)
            {
                // Reiniciar todo
                dt.Clear();
                dtgInventario.DataSource = null;
                txtNumProductos.Clear();
                txtNumProductos.Enabled = true;
                btnCrear.Enabled = true;
                btnInsertar.Enabled = false;
                btnConsultar.Enabled = false;
                btnModificar.Enabled = false;
                btnEliminar.Enabled = false;
                inventario = null;
                productoActual = 0;
                LimpiarEstado();
                txtNumProductos.Focus();
            }
        }
    }

    // Botón Regresar
    private void btnRegresar_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    // ==================== VALIDACIONES ====================

    // Validar solo números en txtNumProductos
    private void txtNumProductos_KeyPress(object sender, KeyPressEventArgs e)
    {
        if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
        {
            e.Handled = true;
        }
    }

    // Validar solo números en txtValor
    private void txtValor_KeyPress(object sender, KeyPressEventArgs e)
    {
        if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
        {
            e.Handled = true;
        }
    }
}
