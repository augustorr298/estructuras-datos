
using System.Data;

namespace SensorSubmarino;

public partial class frmOpeUnidimensional : Form
{
    public frmOpeUnidimensional()
    {
        InitializeComponent();
        btnBuscar.Visible = false;
        btnConsultar.Enabled = false;
        btnEliminar.Enabled = false;
        btnInsertar.Enabled = false;
        btnModificar.Enabled = false;
        btnAceptar.Enabled = false;
        txtElemento.Enabled = false;
        txtNvoEle.Enabled = false;
        txtNoEle.Focus();
    }

    private int[] A;
    private int i = -1, elemento, n, j;
    private string opcion = "";
    DataTable dt = new DataTable();
    bool existe = false;

    // Método de búsqueda: retorna el índice o -1 si no existe
    public int buscarIndice(int elem)
    {
        for (int k = 0; k <= i; k++)
        {
            if (A[k] == elem)
            {
                return k;
            }
        }
        return -1;
    }

    // Método de búsqueda: retorna true/false
    public bool buscar()
    {
        for (j = 0; j <= i; j++)
        {
            if (A[j] == elemento)
            {
                existe = true;
                return true;
            }
        }
        existe = false;
        return false;
    }

    // Mostrar arreglo en DataGridView
    public void mostrarData()
    {
        dt.Clear();
        for (int k = 0; k <= i; k++)
        {
            DataRow fila = dt.NewRow();
            fila["Índice"] = k;
            fila["Valor"] = A[k];
            dt.Rows.Add(fila);
        }
        dtgArreglo.DataSource = null;
        dtgArreglo.DataSource = dt;
    }

    // Limpiar estado de operación
    private void limpiarEstado()
    {
        opcion = "";
        txtElemento.Clear();
        txtNvoEle.Clear();
        txtElemento.Enabled = false;
        txtNvoEle.Enabled = false;
        btnBuscar.Visible = false;
        btnAceptar.Enabled = false;
    }

    // ==================== BOTÓN CREAR ====================
    private void button5_Click(object sender, EventArgs e)
    {
        if (txtNoEle.Text.Trim() != "")
        {
            n = Convert.ToInt32(txtNoEle.Text);
            
            if (n <= 0)
            {
                MessageBox.Show("El tamaño debe ser mayor a 0", "Validación", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNoEle.Focus();
                return;
            }
            
            A = new int[n];
            i = -1; // Reiniciar contador
            
            // Configurar DataTable
            dt = new DataTable();
            dt.Columns.Add("Índice", typeof(int));
            dt.Columns.Add("Valor", typeof(int));
            
            MessageBox.Show("Arreglo creado de tamaño " + n, "Arreglo Creado", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            
            btnInsertar.Enabled = true;
            btnCrear.Enabled = false;
            txtNoEle.Enabled = false;
            
            dtgArreglo.DataSource = dt;
        }
        else
        {
            MessageBox.Show("Ingrese el número de elementos", "Validación", 
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtNoEle.Focus();
        }
    }

    // ==================== BOTÓN INSERTAR ====================
    private void btnInsertar_Click(object sender, EventArgs e)
    {
        if (i >= n - 1)
        {
            MessageBox.Show("El arreglo está lleno. No se pueden insertar más elementos.", 
                "Arreglo Lleno", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        
        opcion = "insertar";
        txtElemento.Enabled = true;
        btnAceptar.Enabled = true;
        txtElemento.Clear();
        txtElemento.Focus();
    }

    // ==================== BOTÓN CONSULTAR ====================
    private void btnConsultar_Click(object sender, EventArgs e)
    {
        if (i < 0)
        {
            MessageBox.Show("El arreglo está vacío.", "Arreglo Vacío", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        
        opcion = "consultar";
        txtElemento.Enabled = true;
        btnAceptar.Enabled = true;
        txtElemento.Clear();
        txtElemento.Focus();
    }

    // ==================== BOTÓN MODIFICAR ====================
    private void btnModificar_Click(object sender, EventArgs e)
    {
        if (i < 0)
        {
            MessageBox.Show("El arreglo está vacío.", "Arreglo Vacío", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        
        opcion = "modificar";
        txtElemento.Enabled = true;
        btnBuscar.Visible = true;
        txtElemento.Clear();
        txtElemento.Focus();
    }

    // ==================== BOTÓN ELIMINAR ====================
    private void btnEliminar_Click(object sender, EventArgs e)
    {
        if (i < 0)
        {
            MessageBox.Show("El arreglo está vacío.", "Arreglo Vacío", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        
        opcion = "eliminar";
        txtElemento.Enabled = true;
        btnAceptar.Enabled = true;
        txtElemento.Clear();
        txtElemento.Focus();
    }

    // ==================== BOTÓN BUSCAR ====================
    private void btnBuscar_Click(object sender, EventArgs e)
    {
        if (txtElemento.Text.Trim() == "")
        {
            MessageBox.Show("Ingrese el elemento a buscar", "Validación", 
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtElemento.Focus();
            return;
        }

        elemento = Convert.ToInt32(txtElemento.Text);
        int indice = buscarIndice(elemento);

        if (indice != -1)
        {
            MessageBox.Show("Elemento " + elemento + " encontrado en la posición " + indice, 
                "Elemento Encontrado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
            if (opcion == "modificar")
            {
                txtNvoEle.Enabled = true;
                btnAceptar.Enabled = true;
                txtNvoEle.Focus();
            }
            txtElemento.Enabled = false;
            btnBuscar.Visible = false;
        }
        else
        {
            MessageBox.Show("Elemento " + elemento + " no encontrado", 
                "No Encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtElemento.Clear();
            txtElemento.Focus();
        }
    }

    // ==================== BOTÓN ACEPTAR ====================
    public void btnAceptar_Click(object sender, EventArgs e)
    {
        switch (opcion)
        {
            case "insertar":
                if (txtElemento.Text.Trim() == "")
                {
                    MessageBox.Show("Ingrese el elemento", "Validación", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtElemento.Focus();
                    return;
                }

                if (i < n - 1)
                {
                    i++;
                    A[i] = Convert.ToInt32(txtElemento.Text);
                    MessageBox.Show("Elemento " + A[i] + " insertado en la posición " + i, 
                        "Elemento Insertado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    btnConsultar.Enabled = true;
                    btnEliminar.Enabled = true;
                    btnModificar.Enabled = true;
                    
                    mostrarData();
                    limpiarEstado();
                }
                else
                {
                    MessageBox.Show("No hay espacio en el arreglo", "Arreglo Lleno", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                break;

            case "consultar":
                if (txtElemento.Text.Trim() == "")
                {
                    MessageBox.Show("Ingrese el elemento a consultar", "Validación", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtElemento.Focus();
                    return;
                }

                elemento = Convert.ToInt32(txtElemento.Text);
                int indiceConsulta = buscarIndice(elemento);

                if (indiceConsulta != -1)
                {
                    MessageBox.Show("ELEMENTO ENCONTRADO\n\n" +
                        "Valor: " + A[indiceConsulta] + "\n" +
                        "Posición: " + indiceConsulta, 
                        "Consulta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Elemento " + elemento + " no existe en el arreglo", 
                        "No Encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                limpiarEstado();
                break;

            case "eliminar":
                if (txtElemento.Text.Trim() == "")
                {
                    MessageBox.Show("Ingrese el elemento a eliminar", "Validación", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtElemento.Focus();
                    return;
                }

                elemento = Convert.ToInt32(txtElemento.Text);
                int indiceEliminar = buscarIndice(elemento);

                if (indiceEliminar != -1)
                {
                    // Desplazar elementos hacia la izquierda
                    for (int k = indiceEliminar; k < i; k++)
                    {
                        A[k] = A[k + 1];
                    }
                    i--; // Reducir contador
                    
                    MessageBox.Show("Elemento " + elemento + " eliminado correctamente", 
                        "Elemento Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    mostrarData();
                    
                    // Si el arreglo quedó vacío, deshabilitar botones
                    if (i < 0)
                    {
                        btnConsultar.Enabled = false;
                        btnEliminar.Enabled = false;
                        btnModificar.Enabled = false;
                    }
                }
                else
                {
                    MessageBox.Show("Elemento " + elemento + " no encontrado", 
                        "No Encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                limpiarEstado();
                break;

            case "modificar":
                if (txtNvoEle.Text.Trim() == "")
                {
                    MessageBox.Show("Ingrese el nuevo valor", "Validación", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtNvoEle.Focus();
                    return;
                }

                int indiceModificar = buscarIndice(elemento);
                if (indiceModificar != -1)
                {
                    int valorAnterior = A[indiceModificar];
                    A[indiceModificar] = Convert.ToInt32(txtNvoEle.Text);
                    
                    MessageBox.Show("Elemento modificado\n\n" +
                        "Valor anterior: " + valorAnterior + "\n" +
                        "Valor nuevo: " + A[indiceModificar], 
                        "Elemento Modificado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    mostrarData();
                }
                limpiarEstado();
                break;
        }
    }

    // ==================== BOTÓN LIMPIAR ====================
    private void btnLimpiar_Click(object sender, EventArgs e)
    {
        DialogResult confirmar = MessageBox.Show(
            "¿Desea reiniciar el arreglo?\nSe perderán todos los datos.",
            "Confirmar Reinicio", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (confirmar == DialogResult.Yes)
        {
            dt.Clear();
            dtgArreglo.DataSource = null;
            txtNoEle.Clear();
            txtNoEle.Enabled = true;
            btnCrear.Enabled = true;
            btnInsertar.Enabled = false;
            btnConsultar.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
            A = null;
            i = -1;
            limpiarEstado();
            txtNoEle.Focus();
        }
    }

    // ==================== BOTÓN REGRESAR ====================
    private void btnRegresar_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    // ==================== BOTÓN SALIR ====================
    private void btnSalir_Click(object sender, EventArgs e)
    {
        Application.Exit();
    }

    // ==================== VALIDACIONES ====================
    private void txtNoEle_KeyPress(object sender, KeyPressEventArgs e)
    {
        if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
        {
            e.Handled = true;
        }
    }

    private void txtElemento_KeyPress(object sender, KeyPressEventArgs e)
    {
        if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
        {
            e.Handled = true;
        }
    }

    private void txtNvoEle_KeyPress(object sender, KeyPressEventArgs e)
    {
        if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
        {
            e.Handled = true;
        }
    }
}