﻿// Cola Doble Lineal Estática
// Frente: crece hacia la derecha (desde 0)
// Detrás: crece hacia la izquierda (desde max-1)

int frenteF = -1, finalF = -1;  // Encolar por el frente
int frenteD = -1, finalD = -1;  // Encolar por detrás
int dato, opcion, max = 10;
int[] cola = new int[10];

do
{
    Console.WriteLine("\n-- COLA DOBLE LINEAL ESTÁTICA --");
    Console.WriteLine("Frente (izquierda →)  |  Detrás (← derecha)");
    Console.WriteLine("1. Encolar por el frente");
    Console.WriteLine("2. Desencolar por el frente");
    Console.WriteLine("3. Encolar por detrás");
    Console.WriteLine("4. Desencolar por detrás");
    Console.WriteLine("5. Consultar");
    Console.WriteLine("6. Imprimir cola");
    Console.WriteLine("7. Salir");
    Console.Write("Opción: ");
    opcion = int.Parse(Console.ReadLine());

    switch (opcion)
    {
        case 1: // Encolar por el frente (crece hacia la derecha)
            if (frenteF == -1)
            {
                // Cola frente vacía, inicializar
                frenteF = 0;
                finalF = 0;
                Console.Write("Ingrese dato: ");
                dato = int.Parse(Console.ReadLine());
                cola[finalF] = dato;
                Console.WriteLine("Dato encolado por el frente, posición " + finalF);
            }
            else
            {
                int nuevoFinalF = finalF + 1;
                
                // Verificar colisión con cola detrás
                if (frenteD != -1 && nuevoFinalF >= finalD)
                {
                    Console.WriteLine("Cola llena - Colisión con cola detrás");
                }
                else if (nuevoFinalF >= max)
                {
                    Console.WriteLine("Cola frente llena");
                }
                else
                {
                    Console.Write("Ingrese dato: ");
                    dato = int.Parse(Console.ReadLine());
                    finalF = nuevoFinalF;
                    cola[finalF] = dato;
                    Console.WriteLine("Dato encolado por el frente, posición " + finalF);
                }
            }
            break;

        case 2: // Desencolar por el frente
            if (frenteF == -1)
            {
                Console.WriteLine("Cola frente vacía");
            }
            else
            {
                Console.WriteLine("Dato desencolado del frente: " + cola[frenteF]);
                cola[frenteF] = 0;
                
                if (frenteF == finalF)
                {
                    frenteF = -1;
                    finalF = -1;
                }
                else
                {
                    frenteF++;
                }
            }
            break;

        case 3: // Encolar por detrás (crece hacia la izquierda)
            if (frenteD == -1)
            {
                // Cola detrás vacía, inicializar desde el final
                frenteD = max - 1;
                finalD = max - 1;
                Console.Write("Ingrese dato: ");
                dato = int.Parse(Console.ReadLine());
                cola[finalD] = dato;
                Console.WriteLine("Dato encolado por detrás, posición " + finalD);
            }
            else
            {
                int nuevoFinalD = finalD - 1;
                
                // Verificar colisión con cola frente
                if (frenteF != -1 && nuevoFinalD <= finalF)
                {
                    Console.WriteLine("Cola llena - Colisión con cola frente");
                }
                else if (nuevoFinalD < 0)
                {
                    Console.WriteLine("Cola detrás llena");
                }
                else
                {
                    Console.Write("Ingrese dato: ");
                    dato = int.Parse(Console.ReadLine());
                    finalD = nuevoFinalD;
                    cola[finalD] = dato;
                    Console.WriteLine("Dato encolado por detrás, posición " + finalD);
                }
            }
            break;

        case 4: // Desencolar por detrás
            if (frenteD == -1)
            {
                Console.WriteLine("Cola detrás vacía");
            }
            else
            {
                Console.WriteLine("Dato desencolado de detrás: " + cola[frenteD]);
                cola[frenteD] = 0;
                
                if (frenteD == finalD)
                {
                    frenteD = -1;
                    finalD = -1;
                }
                else
                {
                    frenteD--;
                }
            }
            break;

        case 5: // Consultar
            Console.Write("Ingrese dato a buscar: ");
            dato = int.Parse(Console.ReadLine());
            bool encontrado = false;
            
            // Buscar en cola frente
            if (frenteF != -1)
            {
                for (int i = frenteF; i <= finalF; i++)
                {
                    if (cola[i] == dato)
                    {
                        Console.WriteLine("Dato encontrado en cola frente, posición " + i);
                        encontrado = true;
                        break;
                    }
                }
            }
            
            // Buscar en cola detrás
            if (!encontrado && frenteD != -1)
            {
                for (int i = frenteD; i >= finalD; i--)
                {
                    if (cola[i] == dato)
                    {
                        Console.WriteLine("Dato encontrado en cola detrás, posición " + i);
                        encontrado = true;
                        break;
                    }
                }
            }
            
            if (!encontrado)
            {
                Console.WriteLine("Dato no encontrado");
            }
            break;

        case 6: // Imprimir cola
            Console.WriteLine("Frente: frenteF=" + frenteF + ", finalF=" + finalF);
            Console.WriteLine("Detrás: frenteD=" + frenteD + ", finalD=" + finalD);
            Console.Write("Arreglo: ");
            for (int j = 0; j < max; j++)
            {
                Console.Write("|" + cola[j] + "|");
            }
            Console.WriteLine();
            break;

        case 7:
            Console.WriteLine("Saliendo...");
            break;

        default:
            Console.WriteLine("Opción no válida");
            break;
    }
} while (opcion != 7);