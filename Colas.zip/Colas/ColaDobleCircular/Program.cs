﻿// Cola Doble Circular Estática
// Ambas colas comparten el mismo arreglo
// Frente: empieza en 0, crece hacia la derecha, envuelve al final
// Detrás: empieza en max-1, crece hacia la izquierda, envuelve al inicio

int frenteF = -1, finalF = -1;  // Encolar por el frente
int frenteD = -1, finalD = -1;  // Encolar por detrás
int dato, opcion, max = 10;
int[] cola = new int[10];

do
{
    Console.WriteLine("\n-- COLA DOBLE CIRCULAR ESTÁTICA --");
    Console.WriteLine("Frente (→ circular)  |  Detrás (← circular)");
    Console.WriteLine("1. Encolar por el frente");
    Console.WriteLine("2. Desencolar por el frente");
    Console.WriteLine("3. Encolar por detrás");
    Console.WriteLine("4. Desencolar por detrás");
    Console.WriteLine("5. Consultar");
    Console.WriteLine("6. Imprimir cola");
    Console.WriteLine("7. Salir");
    Console.Write("Opción: ");
    opcion = int.Parse(Console.ReadLine());

    switch (opcion)
    {
        case 1: // Encolar por el frente (crece →, envuelve)
            int sigPosF;
            if (finalF == -1)
                sigPosF = 0;
            else if (finalF == max - 1)
                sigPosF = 0;
            else
                sigPosF = finalF + 1;
            
            // Verificar colisión con cola detrás
            if (frenteD != -1 && sigPosF == finalD)
            {
                Console.WriteLine("Cola llena - Colisión con cola detrás");
            }
            else if (frenteF != -1 && sigPosF == frenteF)
            {
                Console.WriteLine("Cola frente llena");
            }
            else
            {
                Console.Write("Ingrese dato: ");
                dato = int.Parse(Console.ReadLine());
                
                if (finalF == -1)
                {
                    frenteF = 0;
                    finalF = 0;
                }
                else if (finalF == max - 1)
                {
                    finalF = 0;
                }
                else
                {
                    finalF++;
                }
                
                cola[finalF] = dato;
                Console.WriteLine("Dato encolado por el frente, posición " + finalF);
            }
            break;

        case 2: // Desencolar por el frente
            if (frenteF == -1)
            {
                Console.WriteLine("Cola frente vacía");
            }
            else
            {
                Console.WriteLine("Dato desencolado del frente: " + cola[frenteF]);
                cola[frenteF] = 0;
                
                if (frenteF == finalF)
                {
                    frenteF = -1;
                    finalF = -1;
                }
                else
                {
                    if (frenteF == max - 1)
                        frenteF = 0;
                    else
                        frenteF++;
                }
            }
            break;

        case 3: // Encolar por detrás (crece ←, envuelve)
            int sigPosD;
            if (finalD == -1)
                sigPosD = max - 1;
            else if (finalD == 0)
                sigPosD = max - 1;
            else
                sigPosD = finalD - 1;
            
            // Verificar colisión con cola frente
            if (frenteF != -1 && sigPosD == finalF)
            {
                Console.WriteLine("Cola llena - Colisión con cola frente");
            }
            else if (frenteD != -1 && sigPosD == frenteD)
            {
                Console.WriteLine("Cola detrás llena");
            }
            else
            {
                Console.Write("Ingrese dato: ");
                dato = int.Parse(Console.ReadLine());
                
                if (finalD == -1)
                {
                    frenteD = max - 1;
                    finalD = max - 1;
                }
                else if (finalD == 0)
                {
                    finalD = max - 1;
                }
                else
                {
                    finalD--;
                }
                
                cola[finalD] = dato;
                Console.WriteLine("Dato encolado por detrás, posición " + finalD);
            }
            break;

        case 4: // Desencolar por detrás
            if (frenteD == -1)
            {
                Console.WriteLine("Cola detrás vacía");
            }
            else
            {
                Console.WriteLine("Dato desencolado de detrás: " + cola[frenteD]);
                cola[frenteD] = 0;
                
                if (frenteD == finalD)
                {
                    frenteD = -1;
                    finalD = -1;
                }
                else
                {
                    if (frenteD == 0)
                        frenteD = max - 1;
                    else
                        frenteD--;
                }
            }
            break;

        case 5: // Consultar
            Console.Write("Ingrese dato a buscar: ");
            dato = int.Parse(Console.ReadLine());
            bool encontrado = false;
            
            // Buscar en cola frente (circular →)
            if (frenteF != -1)
            {
                int i = frenteF;
                do
                {
                    if (cola[i] == dato)
                    {
                        Console.WriteLine("Dato encontrado en cola frente, posición " + i);
                        encontrado = true;
                        break;
                    }
                    
                    if (i == finalF) break;
                    
                    if (i == max - 1)
                        i = 0;
                    else
                        i++;
                } while (true);
            }
            
            // Buscar en cola detrás (circular ←)
            if (!encontrado && frenteD != -1)
            {
                int i = frenteD;
                do
                {
                    if (cola[i] == dato)
                    {
                        Console.WriteLine("Dato encontrado en cola detrás, posición " + i);
                        encontrado = true;
                        break;
                    }
                    
                    if (i == finalD) break;
                    
                    if (i == 0)
                        i = max - 1;
                    else
                        i--;
                } while (true);
            }
            
            if (!encontrado)
            {
                Console.WriteLine("Dato no encontrado");
            }
            break;

        case 6: // Imprimir cola
            Console.WriteLine("Frente: frenteF=" + frenteF + ", finalF=" + finalF);
            Console.WriteLine("Detrás: frenteD=" + frenteD + ", finalD=" + finalD);
            Console.Write("Arreglo: ");
            for (int j = 0; j < max; j++)
            {
                Console.Write("|" + cola[j] + "|");
            }
            Console.WriteLine();
            break;

        case 7:
            Console.WriteLine("Saliendo...");
            break;

        default:
            Console.WriteLine("Opción no válida");
            break;
    }
} while (opcion != 7);
