
using System.Data;

namespace SensorSubmarino;

public partial class frmOpeUnidimensional : Form
{
    public frmOpeUnidimensional()
    {
        InitializeComponent();
        btnBuscar.Visible=false;
        btnConsultar.Enabled = false;
        btnEliminar.Enabled = false;
        btnInsertar.Enabled = false;
        btnModificar.Enabled = false;
        btnAceptar.Enabled=false;
        txtElemento.Enabled = false;
        txtNvoEle.Enabled = false;
        txtNoEle.Focus();
    }
    
        
    private int[] A;
    private int i = -1, elemento, nvoEle, n,j;
    private string opcion = "";
    DataTable dt = new DataTable();
    
    bool existe =false;

    public bool buscar()
    {
        for (j = 0; j <= i; j++)
        {
            if (A[j] == elemento)
            {
                existe = true;
                break;
            }
            else
            {
                existe = false;
            }
        }
        return existe;
    }

    //btnCrear
    private void button5_Click(object sender, EventArgs e)
    {
        if (txtNoEle.Text.Trim() != "")
        {
            n = Convert.ToInt32(txtNoEle.Text);
            A= new int[n];//crear arreglo de tamaño n
            MessageBox.Show("El arreglo se creó de tamaño " + n);
            btnInsertar.Enabled = true;
            txtNoEle.Enabled = true;
            dt.Columns.Add("Arreglo",typeof(int));
        //    btnCrear.Enabled= false;
        }
        else
        {
            MessageBox.Show("Ingrese el número de elementos");
            txtNoEle.Focus();//manda cursor

        }
    }

    private void btnInsertar_Click(object sender, EventArgs e)
    {
        opcion= "insertar";
        txtElemento.Enabled = true;
        btnAceptar.Enabled = true;
        txtElemento.Focus();
        
    }

    public void mostrarData()
    {

        dtgArreglo.DataSource = dt;
    }
    public void btnAceptar_Click(object sender, EventArgs e)
    {
        switch (opcion)
        {
            case "insertar":
           //     MessageBox.Show(n);
             //   dt.Columns.Add("Arreglo", typeof(int));
                if (i < n - 1) //sí hay espacio en el arreglo{
                {
                    i++;


                    if (txtElemento.Text.Trim() != "")
                    {
                        A[i] = Convert.ToInt32(txtElemento.Text);
                        MessageBox.Show("Elemento insertado");
                        txtElemento.Clear();
                        txtElemento.Enabled = false;
                        btnConsultar.Enabled = true;
                        btnEliminar.Enabled = true;
                        btnModificar.Enabled = true;
                        mostrarData();
                    }
                    else
                    {
                        MessageBox.Show("Ingrese el elemento");
                        txtElemento.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("No hay espacio en el arreglo");
                    txtElemento.Enabled = true;
                    txtElemento.Clear();
                }

                break;
            case "eliminar":
                bool eliminado = false;
                if (txtNvoEle.Text.Trim() != "")
                {

                    for (int k = 0; k <= i; k++)
                    {
                        if (A[k] == elemento)
                        {
                            A[k] = 0;
                            eliminado = true;
                        }
                    }

                    if (eliminado)
                    {
                        MessageBox.Show("Elemento eliminado");
                        txtNvoEle.Clear();
                        txtNvoEle.Enabled=false;

                    }
                    
                }
                else
                {
                    MessageBox.Show("Ingrese el nuevo valor del elemento");
                    txtNvoEle.Focus();
                }
                break;
            case "modificar":
                bool modificado = false;
                if (txtNvoEle.Text.Trim() != "")
                {

                    for (int k = 0; k <= i; k++)
                    {
                        if (A[k] == elemento)
                        {
                            A[k] = Convert.ToInt32(txtNvoEle.Text);
                            modificado = true;
                        }
                    }

                    if (modificado)
                    {
                        MessageBox.Show("Elemento modificado");
                        txtNvoEle.Clear();
                        txtNvoEle.Enabled=false;

                    }
                    
                }
                else
                {
                    MessageBox.Show("Ingrese el nuevo valor del elemento");
                    txtNvoEle.Focus();
                }
                break;
        }
        mostrarData();
    }

    private void txtNoEle_KeyPress(object sender, KeyPressEventArgs e)
    {
        if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
        {
            e.Handled=true;
        }
    }

    private void txtElemento_KeyPress(object sender, KeyPressEventArgs e)
    {
        if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
        {
            e.Handled=true;
        }
    }

    private void txtNvoEle_KeyPress(object sender, KeyPressEventArgs e)
    {
        if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
        {
            e.Handled=true;
        }
    }

    private void btnModificar_Click(object sender, EventArgs e)
    {
        opcion = "modificar";
        txtElemento.Enabled=true;
        btnBuscar.Visible = true;
        txtElemento.Focus();
    }

    private void btnBuscar_Click(object sender, EventArgs e)
    {
        if (txtElemento.Text.Trim() != "")
        {
            elemento = Convert.ToInt32(txtElemento.Text);
            if (buscar())
            {
                MessageBox.Show("El elemento sí existe");
                if (opcion == "modificar")
                {
                    txtNvoEle.Enabled = true;
                    txtNvoEle.Focus();
                    
                }
                txtElemento.Enabled = false;
                txtElemento.Clear();
                btnBuscar.Visible = false;
            }
            else
            {
                MessageBox.Show("El elemento no existe");
                txtElemento.Clear();
                txtElemento.Focus();
            }
            
        }
        else
        {
            MessageBox.Show("Ingrese el elemento a buscar");
            txtElemento.Focus();
        }
    }

    private void btnEliminar_Click(object sender, EventArgs e)
    {
        opcion = "eliminar";
        btnBuscar.Visible = true;
        txtElemento.Enabled = true;
        txtElemento.Focus();
    }
    
}